package com.att.converters;

import org.bson.types.ObjectId;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.commands.CustomerCartForm;
import com.att.domain.Cart;

/**
 * Created by jt on 1/10/17.
 */
@Component
public class CartFormToCart implements Converter<CustomerCartForm, Cart> {

	@Override
	public Cart convert(CustomerCartForm customerCartForm) {
		Cart cart = new Cart();
		if (customerCartForm.getId() != null && !StringUtils.isEmpty(customerCartForm.getId())) {
			cart.setId(new ObjectId(customerCartForm.getId()));
		}
		cart.setCustId(customerCartForm.getCustId());
		cart.setTotalPrice(customerCartForm.getTotalPrice());
		return cart;
	}
}

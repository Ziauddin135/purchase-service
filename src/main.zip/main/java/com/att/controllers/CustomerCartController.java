package com.att.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.commands.CustomerCartForm;
import com.att.commands.LineItemForm;
import com.att.domain.Cart;
import com.att.domain.LineItem;
import com.att.services.CartService;
import com.att.services.LineItemService;

/**
 * Created by jt on 1/10/17.
 */
@RestController
@RequestMapping(value = "/purchase-service/v1/cart")
public class CustomerCartController {

	@Autowired
	CartService cartService;

	@Autowired
	LineItemService lineItemService;

	
	@RequestMapping(value = "/getItemCounts", method = RequestMethod.GET, produces = { "application/json",
	"application/xml" })
	public String getItemCounts(@RequestParam Map<String, String> requestParams,
			HttpServletRequest request, HttpServletResponse response) {
		return ""+lineItemService.getLineItemsCount(requestParams.get("custId"));
	}

	public List<LineItemForm> getLineItems() {
		return new ArrayList<LineItemForm>();
	}

	@RequestMapping(value = "/deleteItem/", method = RequestMethod.GET)
	public void deleteLineIem(@RequestParam Map<String, String> requestParams, HttpServletRequest request,
			HttpServletResponse response) {
		lineItemService.deleteLineItem(requestParams.get("custId"), requestParams.get("id"));
	}

	@RequestMapping(value = "/getCartItems", method = RequestMethod.GET, produces = { "application/json",
			"application/xml" })
	public @ResponseBody List<LineItem> getCartItems(@RequestParam Map<String, String> requestParams,
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println("reaching...............id" + requestParams.get("id"));
		System.out.println("reaching...............custId" + requestParams.get("custId"));
		// System.out.println("reaching...............custId"+requestParams.get("items"));
		System.out.println("reaching...............");
		Cart cart = cartService.getCartByCustId(requestParams.get("custId") + "");
		return lineItemService.getLineItemsByCartId(cart.getId().toHexString());
		// return "redirect:/product/list";
	}

	@RequestMapping(value = "/addToCart", method = RequestMethod.GET, produces = { "application/json",
			"application/xml" })
	public @ResponseBody void addToCart(@RequestParam Map<String, String> requestParams,
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println("reaching...............id" + requestParams.get("id"));
		System.out.println("reaching...............custId" + requestParams.get("custId"));
		// System.out.println("reaching...............custId"+requestParams.get("items"));
		System.out.println("reaching...............");
		lineItemService.saveLineItem(requestParams.get("custId"), requestParams.get("id"));
		// return "redirect:/product/list";
	}
}

package com.att.repository;

import com.att.domain.Cart;

public class CartRepositoryImpl implements CartRepositoryCustom {

	@Override
	public Cart findCartByCustomer(String custId) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.att.repository;

import java.util.List;

import com.att.domain.LineItem;

public class LineItemRepositoryCustomImpl {
	

	
	/*public List<LineItem> findLineItemsByCartIdAndProductId(String cartId, String productId) {
		
	}
*/
}

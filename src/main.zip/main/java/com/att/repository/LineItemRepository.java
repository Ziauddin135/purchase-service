package com.att.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.att.domain.LineItem;

public interface LineItemRepository extends CrudRepository<LineItem, String> {
	List<LineItem> findLineItemByCartId(String cartId);
	LineItem findLineItemByCartIdAndProductId(String cartId, String productId);
}

package com.att.repository;

import java.util.List;

import com.att.domain.LineItem;

public interface LineItemRepositoryCustom {
	List<LineItem> findLineItemsByCartId(String cartId);
	LineItem findLineItemsByCartId(String cartId, String productId);
}

package com.att.repository;

import com.att.domain.Cart;

/**
 * Created by jt on 1/10/17.
 */
public interface CartRepositoryCustom /*extends CrudRepository<Cart, String>*/ {
	
	Cart findCartByCustomer(String custId);
}

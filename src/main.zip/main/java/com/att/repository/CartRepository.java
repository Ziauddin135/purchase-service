package com.att.repository;

import org.springframework.data.repository.CrudRepository;

import com.att.domain.Cart;

public interface CartRepository extends CrudRepository<Cart, String> {
	public Cart findCartByCustId(String custId);
}

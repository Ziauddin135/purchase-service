package com.att.services;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.converters.LineItemFormToLineItem;
import com.att.domain.Cart;
import com.att.domain.LineItem;
import com.att.repository.CartRepository;
import com.att.repository.LineItemRepository;

@Service
public class LineItemService {

	@Autowired
	LineItemRepository lineItemRepository;

	@Autowired
	CartRepository cartRepository;

	@Autowired
	CartService cartService;

	@Autowired
	LineItemFormToLineItem lineItemFormToLineItem;

	public List<LineItem> getLineItemsByCartId(String cartId) {
		List<LineItem> lineItems = lineItemRepository.findLineItemByCartId(cartId);
		return lineItems;
	}

	public int getLineItemsCount(String custId) {
		Cart cart = cartService.getCartByCustId(custId);
		if (cart == null) {
			cart = cartService.save(custId);
		}
		List<LineItem> lineItems = lineItemRepository.findLineItemByCartId(cart.getId().toHexString());
		return (lineItems != null ? lineItems.size() : 0);
	}

	public void saveLineItem(String productId, String custId) {
		Cart cart = cartService.getCartByCustId(custId);
		String cartId = cart.getId().toHexString();

		LineItem lineItem = lineItemRepository.findLineItemByCartIdAndProductId(cartId, productId);
		if (lineItem == null) {
			lineItem = new LineItem();
			lineItem.setCartId(cartId);
			lineItem.setProductId(productId);
			lineItem.setTotalPrice(new BigDecimal("0"));
		}
		BigDecimal totalPrice = lineItem.getTotalPrice();
		lineItem.setTotalPrice(totalPrice.add(totalPrice));
		lineItemRepository.save(lineItem);
	}

	/*public void save(String lineItemId) {
		lineItemRepository.delete(lineItemId);
	}*/
	
	public void deleteLineItem(String custId, String productId) {
		Cart cart = cartRepository.findCartByCustId(custId);
		lineItemRepository.findLineItemByCartIdAndProductId(cart.getId().toHexString(), productId);
	}

	public void deleteCart(String cartId) {
		lineItemRepository.delete(getLineItemsByCartId(cartId));
	}

}

package com.att.services;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.att.domain.LineItem;

@FeignClient("purchase-service")
interface CartServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/purchase-service/v1/cart/getCartItems")
	List<LineItem> getCartItems(@RequestParam Map<String, String> requestParams);

	@RequestMapping(method = RequestMethod.GET, value = "/purchase-service/v1/cart/addToCart")
	void addToCart(@RequestParam Map<String, String> requestParams);

}